import React, { useMemo, useRef, useState } from "react";
import {
  Recycle, Camera, IndianRupee, MapPin, Package, WalletCards,
  ArrowRight, CheckCircle2, ShieldCheck, TrendingUp, QrCode,
  Plus, Search, X, Leaf, Smartphone, Laptop, Battery,
  Cable, CircuitBoard, ChevronRight
} from "lucide-react";
import "./App.css";

const MATERIALS = {
  "Mobile Phone": { icon: Smartphone, min: 180, max: 300, unit: "kg" },
  "Laptop": { icon: Laptop, min: 250, max: 450, unit: "kg" },
  "PCB / Motherboard": { icon: CircuitBoard, min: 250, max: 400, unit: "kg" },
  "Battery": { icon: Battery, min: 80, max: 150, unit: "kg" },
  "Charger / Cable": { icon: Cable, min: 100, max: 180, unit: "kg" },
};

const recyclers = [
  { name: "GreenCycle Recycling", distance: "2.4 km", verified: true, accepts: "PCB, Laptop, Mobile", offer: "Fair market offer" },
  { name: "EcoLoop E-Waste", distance: "4.1 km", verified: true, accepts: "Battery, Cable, Mobile", offer: "Same-day pickup" },
  { name: "CleanTech Recycler", distance: "6.8 km", verified: true, accepts: "All common e-waste", offer: "Digital handover" },
];

const seedLots = [
  { id: "EW-IND-00021", material: "PCB / Motherboard", weight: 1.5, value: 525, status: "Completed", date: "Today" },
  { id: "EW-IND-00018", material: "Mobile Phone", weight: 2, value: 480, status: "Completed", date: "08 Sep" },
];

export default function App() {
  const [active, setActive] = useState("home");
  const [lots, setLots] = useState(seedLots);
  const [material, setMaterial] = useState("PCB / Motherboard");
  const [weight, setWeight] = useState("1.5");
  const [photo, setPhoto] = useState(null);
  const [notice, setNotice] = useState("");
  const [showScan, setShowScan] = useState(false);
  const fileRef = useRef();

  const pricing = MATERIALS[material];
  const estimate = useMemo(() => {
    const w = Number(weight) || 0;
    return { min: Math.round(w * pricing.min), max: Math.round(w * pricing.max) };
  }, [weight, pricing]);

  const total = lots.reduce((s, l) => s + l.value, 0);

  const identify = () => {
    setMaterial("PCB / Motherboard");
    setWeight("1.5");
    setShowScan(false);
    setNotice("AI identified the item as PCB / Motherboard. Review the result and create a lot.");
    setActive("scan");
  };

  const createLot = () => {
    const value = Math.round((estimate.min + estimate.max) / 2);
    const id = `EW-IND-${String(lots.length + 22).padStart(5, "0")}`;
    setLots([{ id, material, weight: Number(weight), value, status: "Awaiting Recycler", date: "Just now" }, ...lots]);
    setNotice(`Lot ${id} created successfully.`);
    setActive("lots");
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div>
          <div className="brand">
            <div className="brand-icon"><Recycle size={25}/></div>
            <div><b>E-Waste Saathi</b><span>Collector Portal</span></div>
          </div>
          <nav>
            <Nav active={active} id="home" label="Dashboard" icon={<TrendingUp size={18}/>} setActive={setActive}/>
            <Nav active={active} id="scan" label="Scan E-Waste" icon={<Camera size={18}/>} setActive={setActive}/>
            <Nav active={active} id="prices" label="Today's Prices" icon={<IndianRupee size={18}/>} setActive={setActive}/>
            <Nav active={active} id="recyclers" label="Find Recycler" icon={<MapPin size={18}/>} setActive={setActive}/>
            <Nav active={active} id="lots" label="My Lots" icon={<Package size={18}/>} setActive={setActive}/>
            <Nav active={active} id="earnings" label="My Earnings" icon={<WalletCards size={18}/>} setActive={setActive}/>
          </nav>
        </div>
        <div className="trust-card">
          <ShieldCheck size={22}/>
          <b>Formal recycling</b>
          <p>Know the fair value. Create a traceable handover.</p>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">INDORE • COLLECTOR ACCOUNT</div>
            <h1>{active === "home" ? "Good afternoon 👋" : pageTitle(active)}</h1>
          </div>
          <div className="profile">SN</div>
        </header>

        {notice && <div className="notice"><CheckCircle2 size={18}/>{notice}<button onClick={()=>setNotice("")}><X size={16}/></button></div>}

        {active === "home" && <Dashboard total={total} lots={lots} setActive={setActive}/>}
        {active === "scan" && (
          <section className="content">
            <div className="hero-card">
              <div><span className="pill">AI-ASSISTED</span><h2>Identify your e-waste</h2><p>Take a photo, confirm the category and get a fair-value estimate.</p></div>
              <div className="hero-symbol"><Camera size={42}/></div>
            </div>
            <div className="scan-grid">
              <div className="panel upload-panel" onClick={()=>fileRef.current?.click()}>
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={e=>{if(e.target.files?.[0]){setPhoto(URL.createObjectURL(e.target.files[0]));setShowScan(true)}}}/>
                {photo ? <img src={photo} className="preview"/> : <><div className="upload-icon"><Camera size={28}/></div><h3>Upload / capture photo</h3><p>JPG, PNG • Works on entry-level Android</p></>}
                <button className="primary">{photo ? "Use this photo" : "Choose photo"} <ArrowRight size={17}/></button>
              </div>
              <div className="panel">
                <div className="section-head"><div><h3>Quick category</h3><p>For demo or manual confirmation</p></div></div>
                <div className="material-list">{Object.entries(MATERIALS).map(([name, m]) => {const I=m.icon;return <button className={material===name?"material selected":"material"} key={name} onClick={()=>setMaterial(name)}><I size={19}/><span>{name}</span><ChevronRight size={16}/></button>})}</div>
              </div>
            </div>
            {(showScan || active==="scan") && <div className="panel result">
              <div className="result-head"><div><span className="pill">AI RESULT</span><h2>{material}</h2><p>Confidence 94% • Please verify before selling</p></div><div className="confidence">94%</div></div>
              <div className="form-row">
                <label>Weight (kg)<input type="number" min="0" step="0.1" value={weight} onChange={e=>setWeight(e.target.value)}/></label>
                <div className="estimate"><span>Estimated fair value</span><strong>₹{estimate.min} – ₹{estimate.max}</strong><small>Based on current reference prices</small></div>
              </div>
              <button className="primary wide" onClick={createLot}>Create digital lot <ArrowRight size={18}/></button>
            </div>}
          </section>
        )}
        {active === "prices" && <Prices setActive={setActive}/>}
        {active === "recyclers" && <Recyclers material={material}/>}
        {active === "lots" && <Lots lots={lots}/>}
        {active === "earnings" && <Earnings total={total} lots={lots}/>}
      </main>

      <button className="mobile-scan" onClick={()=>setActive("scan")}><Camera size={20}/> Scan</button>
    </div>
  );
}

function Nav({active,id,label,icon,setActive}) {
  return <button className={active===id?"nav active":"nav"} onClick={()=>setActive(id)}>{icon}<span>{label}</span>{active===id&&<ChevronRight size={15}/>}</button>
}
function pageTitle(a){return ({scan:"Scan & identify e-waste",prices:"Today's fair-price reference",recyclers:"Verified recyclers near you",lots:"Your digital e-waste lots",earnings:"Your earnings ledger"})[a]}

function Dashboard({total,lots,setActive}) {
  return <section className="content">
    <div className="hero-card dashboard-hero"><div><span className="pill">VERNACULAR • OFFLINE-FRIENDLY</span><h2>Turn scrap into traceable value.</h2><p>Identify e-waste, see a fair price, find a verified recycler and keep your earnings record.</p><button className="primary" onClick={()=>setActive("scan")}><Camera size={18}/> Scan e-waste</button></div><div className="hero-symbol big"><Leaf size={70}/></div></div>
    <div className="stats"><Stat label="Total earnings" value={`₹${total.toLocaleString("en-IN")}`} icon={<IndianRupee/>}/><Stat label="Digital lots" value={lots.length} icon={<Package/>}/><Stat label="Completed handovers" value={lots.filter(x=>x.status==="Completed").length} icon={<CheckCircle2/>}/><Stat label="Recycler network" value="24" icon={<Recycle/>}/></div>
    <div className="two-col"><div className="panel"><div className="section-head"><div><h3>Recent lots</h3><p>Traceable handover records</p></div><button className="link" onClick={()=>setActive("lots")}>View all</button></div>{lots.slice(0,3).map(l=><LotRow key={l.id} lot={l}/>)}</div><div className="panel"><div className="section-head"><div><h3>Quick actions</h3><p>What do you want to do?</p></div></div><Action onClick={()=>setActive("scan")} icon={<Camera/>} title="Identify e-waste" text="Photo + AI category"/><Action onClick={()=>setActive("prices")} icon={<IndianRupee/>} title="Check fair prices" text="Reference range by material"/><Action onClick={()=>setActive("recyclers")} icon={<MapPin/>} title="Find recycler" text="Verified nearby partners"/></div></div>
  </section>
}
function Stat({label,value,icon}){return <div className="stat"><div className="stat-icon">{icon}</div><span>{label}</span><strong>{value}</strong></div>}
function Action({onClick,icon,title,text}){return <button className="action" onClick={onClick}>{icon}<div><b>{title}</b><span>{text}</span></div><ChevronRight/></button>}
function LotRow({lot}){return <div className="lot-row"><div className="lot-icon"><Package size={18}/></div><div><b>{lot.id}</b><span>{lot.material} • {lot.weight} kg</span></div><div className="lot-right"><strong>₹{lot.value}</strong><small>{lot.status}</small></div></div>}
function Prices({setActive}){return <section className="content"><div className="section-head page-section"><div><span className="pill">REFERENCE DATA</span><h2>Today's material prices</h2><p>Use the range as a negotiation reference; final recycler offers may vary by quality and location.</p></div></div><div className="price-grid">{Object.entries(MATERIALS).map(([name,m])=>{const I=m.icon;return <div className="price-card" key={name}><I size={24}/><b>{name}</b><span>per kg</span><strong>₹{m.min} – ₹{m.max}</strong><small><TrendingUp size={14}/> Reference range</small></div>})}</div><div className="info"><ShieldCheck size={22}/><div><b>Why price transparency?</b><p>Collectors can compare offers instead of accepting an unknown rate. Transaction history can later power price trends and anomaly alerts.</p></div></div></section>}
function Recyclers({material}){return <section className="content"><div className="map-banner"><MapPin size={24}/><div><b>Showing verified recyclers around Indore</b><span>Material selected: {material}</span></div><button className="outline"><Search size={16}/> Search</button></div><div className="recycler-list">{recyclers.map(r=><div className="recycler" key={r.name}><div className="recycler-logo"><Recycle size={25}/></div><div className="recycler-info"><div><b>{r.name}</b>{r.verified&&<span className="verified"><ShieldCheck size={13}/> Verified</span>}</div><span>{r.distance} away • {r.accepts}</span><small>{r.offer}</small></div><button className="primary small">View <ArrowRight size={15}/></button></div>)}</div></section>}
function Lots({lots}){return <section className="content"><div className="panel"><div className="section-head"><div><h2>Digital lot history</h2><p>Every lot creates a traceable record from collection to handover.</p></div><div className="qr"><QrCode size={24}/></div></div>{lots.map(l=><div className="lot-card" key={l.id}><div className="lot-main"><div className="lot-icon"><Package/></div><div><b>{l.id}</b><span>{l.material} • {l.weight} kg • {l.date}</span></div></div><div><strong>₹{l.value}</strong><span className={l.status==="Completed"?"status done":"status"}>{l.status}</span></div></div>)}</div></section>}
function Earnings({total,lots}){return <section className="content"><div className="earn-card"><div><span>Total recorded earnings</span><strong>₹{total.toLocaleString("en-IN")}</strong><small>Across {lots.length} digital lots</small></div><WalletCards size={54}/></div><div className="panel"><div className="section-head"><div><h3>Earnings ledger</h3><p>Simple record of completed transactions</p></div></div>{lots.map(l=><LotRow key={l.id} lot={l}/>)}</div></section>}

const styles = "";
